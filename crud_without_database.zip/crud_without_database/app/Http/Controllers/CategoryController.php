<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        //$blogs = Blog::with('category')->latest()->paginate(10);;
        $categories = Category::all();

        return view('categories.index', compact('categories'));
    }

    /**
     * Show the form for creating a new resource.
     */
    

    /**
     * Store a newly created resource in storage.
     */
    // public function create()
    // {
    //   return view('blogs.create');
    // }
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|min:3|max:255',
            'slug' => 'required|min:3|max:255|unique:blogs',
            
        ]);
        //  $request->validate([
        //      'image_path' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        //  ]);
         //$request->file('image_path')->getClientOriginalName();
         //$request->file('image_path')->store('public/images');
         

         $category = new Category;
         $category->name = $request->name;
         $category->slug = $request->slug;
        $category->save();

        // Blog::create($request->post());

        return redirect()->route('categories.index')->with('success','category has been created successfully.');

    }
   
  
    /**
     * Write code on Method
     *
     * @return response()
     */
    
   
    /**
     * Display the specified resource.
     */
    

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $category= Category::find($id);
        return response()->json([
          'status'=>200,
          'category'=>$category,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request,$id)
    {
        $validatedData = $this->validate($request, [
            'name'         => 'required|min:3|max:50',
            'slug'          => 'required|min:3|max:255|unique:categories',
            
          ]);
    
        //   $validatedData['slug'] = Str::slug($validatedData['slug'], '-');
    //$id= $request->input('id');
     $category=Category::find($id);
    // dd($category);
     $category->name= $request->input('name');
     $category->slug= $request->input('slug');
     
     $category->update($validatedData);;
     
          $category->save();
    
         
            
          
    
          //Session::flash('success', 'You have successfully updated a post!');
    if($category){
          return response()->json(['status'=>200,'message'=>'data updated successfully','category'=>$category]);
        }
        else{
            return response()->json(['status'=>400,'message'=>'cannot update data']);

        }
        }


    

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Category $category)
    {
        $category->delete();
        return redirect()->route('categories.index')->with('success','category has been deleted successfully');

    }
}
