<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use App\Models\Category;
use App\Models\Cat;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Input;
class BlogController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    // public function index()
    // {

    // //     $blogs = Blog::with('category')->latest()->paginate(3);;
    // //     $categories = Category::all();

    // //     return view('blogs.index', compact('blogs','categories'));
    // //return['name'=>"jaya"];
    // }

    // public function index()
    // {

    //     $blogs = Blog::with('cats')->latest()->paginate(10);;
    //     $cats = Cat::all();

    //     return view('blogs.index', compact('blogs','cats'));
    // }

    /**
     * Show the form for creating a new resource.
     */
    

    /**
     * Store a newly created resource in storage.
     */
    
    public function store(Request $request)
    {
        // $request->validate([
        //     'name' => 'required|min:3|max:255',
            // 'slug' => 'required|min:3|max:255|unique:blogs',
            // 'description'   => 'required|min:3',
            //  'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        //]);
        //  $request->validate([
        //      'image_path' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        //  ]);
         //$request->file('image_path')->getClientOriginalName();
         //$request->file('image_path')->store('public/images');
          // $fileName = time() . '.' . $request->image->extension();
          // $request->image->storeAs('public/images', $fileName);

        //  $blog = new Blog;
       

        
         //$blogs = ['name'=>$request->input('name'),'description'=>$request->input('description')];
        // $blogs = ['name'=>'harish'];
         
        //  foreach ($blogs as $blog) {
        //   //echo $blog['value'];
     
        //  dd($blogs['name']);
        // }
       
       // dd($blog);
       $name = $request->name;
          $slug = $request->slug;
        // $blog->category_id = $request->category_id;
         //$image = $fileName;
         //dd($image);
         $description = $request->description;
        //  $blog->save();

        // Blog::create($request->post());
        //return view('blogs.index', ['name' => $blog]);
        return view('blogs.index',compact('name','slug','description'));
        //return redirect()->route('blogs.index')->with('name', $name);
        

    }
   
  
    /**
     * Write code on Method
     *
     * @return response()
     */
    
   
    /**
     * Display the specified resource.
     */
    // public function show(blog $blog)
    // {
    //     return view('blogs.show',compact('blog'));
    // }

    /**
     * Show the form for editing the specified resource.
     */
    // public function edit(blog $blog)
    // {
        
    //     return view('blogs.edit',compact('blog'));
    // }
    public function edit(Request $request )
    {
         //$blog= Blog::find($id);
          // $blog = $request->input('editid');
          // dd($blog);
         //return view('blogs.edit', compact('blog'));

        return response()->json([
          'status'=>200,
          // 'blog'=>$blog,
        ]);
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $validatedData = $this->validate($request, [
            'name'         => 'min:3|max:255',
            'slug'          => 'min:3|max:255' ,
            'image'         => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'description'   => 'min:3'
          ]);
    
        //   $validatedData['slug'] = Str::slug($validatedData['slug'], '-');
    
         
    
    //      $request->validate([
    //       'name' => 'required|min:3|max:255',
    //       'slug' => 'required|min:3|max:255|unique:blogs',
    //       'description'   => 'required|min:3',
    //        'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
    //   ]);
      //  $request->validate([
      //      'image_path' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
      //  ]);
       //$request->file('image_path')->getClientOriginalName();
      //  $request->file('image_path')->store('public/images');
      //   $fileName = time() . '.' . $request->image->extension();
      //   $request->image->storeAs('public/images', $fileName);

       $blog = Blog::find($id);
       $blog->name = $request->input('name');
       $blog->slug = $request->input('slug');
       //$blog->category_id = $request->input('category_id');
       //$blog->image = $fileName;
       $blog->description = $request->input('description');
       $blog->update($validatedData);
       $blog->save();
    
          //Session::flash('success', 'You have successfully updated a post!');
    if($blog){
          return response()->json([
            'status'=>200,
            'blog'=>$blog,
          ]);
        }
        else{
            return response()->json([
                'status'=>400,
                'message'=>"cannot update data",
              ]);

        }
        }


    

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(blog $blog)
    {
        $blog->delete();
        return redirect()->route('blogs.index')->with('success','blog has been deleted successfully');

    }
}
