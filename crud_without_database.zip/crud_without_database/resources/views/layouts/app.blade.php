@include('blogs.modals.create')
@include('blogs.modals.edit')
@include('categories.modals.create')
@include('categories.modals.edit')


<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
    <title>Blog</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" > -->
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script> -->
   
        <style>
            
/* Typography */
@import url('https://fonts.googleapis.com/css2?family=Lora&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Lora&family=Ubuntu:wght@300;400;700&display=swap');
body {
    margin: 0;
    font-family: 'Ubuntu', sans-serif;
    font-size: 1.125rem;
    font-weight: 300;
}
h1, 
h2,
h3 {
    font-family: 'Lora', serif;
    font-weight: 400;
    color: #143774;
    margin-top: 0;
}
h1{
  font-size: 2rem;
  margin: 0;
}
a {
    color: #1792d2;
}

a:hover,
a:focus {
    color: #143774;
}

strong {
    font-weight: 700;
}
.subtitle{
  font-size: 0.85rem;
  font-weight: 700;
  margin: 0;
  color: #1792d2;
  letter-spacing: 0.05em;
  font-family: 'Ubuntu Bold', sans-serif;
}
.article-title {
    font-size: 1.5rem;
}

.article-read-more,
.article-info {
    font-size: .875rem;
}

.article-read-more {
    color: #1792d2;
    text-decoration: none;
    font-weight: 700;
}
.article-read-more:hover,
.article-read-more:focus {
    color: #143774;
    text-decoration: underline;
}
.article-info {
    margin: 2em 0;
}
header{
  padding: 1rem 0;
  text-align: center;
  background: #f0f8ff;
  font-family: sans-serif;
  margin-bottom: 3em;
}
.container-flex{
  max-width: 70vw;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  margin-bottom: 1em;
}
nav ul{
  display: flex;
  justify-content: center;
  list-style: none;
  padding: 0;
}
nav li{
  margin: 0 1em;
}
nav a{
  text-decoration: none;
  color: #707070;
  font-weight: 700; 
  padding: 0.25em 0;
}

nav a:hover,
nav a:focus{
  color: #143774;
  border-bottom: 1px solid black;
  transition: .3s ease;
}

img{
  max-width: 100%;
  display: block;
}
main{
  max-width: 75%;
}
.article-body{
  width: 100%;
  text-align: justify;
}
.sidebar{
  max-width: 23%;
}
footer {
    background:#143774;
    color: white;
    text-align: center;
    padding: 3em 0;
}
footer a{
  text-decoration: none;
  color: white;
}
footer a:hover{
  text-decoration: underline;
  color: white;
}
@media (max-width:1050px){
  .container-flex{
    flex-direction: column;
  }
  .site-title, .subtitle{
    width: 100%;
  }
  main{
    max-width: 100%;
  }
  .sidebar{
    max-width: 100%;
  }
  
}
@media (max-width: 500px){
  nav ul{
    display: flex;
    flex-direction: column;
  }
  nav li{
    margin: 0.5em 0;
  }
}

/* articles */
.article-featured {
    border-bottom: #707070 1px solid;
    padding-bottom: 2em;
    margin-bottom: 2em;
}
.article-recent {
    display: flex;
    flex-direction: column;
    margin-bottom: 2em;
}

.article-recent-main {
    order: 2;
}

.article-recent-secondary {
    order: 1;
}

.container_btn{
  position: relative;
}
.center_btn{
  margin: 0;
  width:100%;
}
@media (min-width: 675px) {
    .article-recent {
        flex-direction: row;
        justify-content: space-between;
    }
    
    .article-recent-main {
        width: 68%;
    }
    
    .article-recent-secondary {
        width: 30%;
    }
}
.container_btn{
  position: relative;
}
.center_btn{
  margin: 0;
  width:100%;
}

.article-image{
  width:100%;
  height:300px;
  margin-top:10px;
  margin-bottom:10px;
}

.category{height:300px;}
          .container_btn{
  position: relative;
}
.center_btn{
  margin: 0;
  width:100%;
}

#msg{
  display:none;
}


#msg-danger{
  display:none;
} */

.show{
  display:block;
}

.hide{
  display:none;
};

#nameErrorMsg{
color: #cc0033;
  display: inline-block;
  font-size: 12px;
  line-height: 15px;
  margin: 5px 0 0;
}
/* #blogModal.hide{
  display:none;
};

#editCategoryModal.hide{
  display:none;
};


/* .article-body.more-text{
  display:none;
} */

        </style>
    </head>
    <body>
    <header>
      <div class='container container-flex'>
        <div class='site-title'>
          <h1>Living The Social Life</h1>
          <p class='subtitle'>A blog exploring minimalism in life.</p>
        </div>
        <nav>
          <ul>
            <li> <a href="{{url('/')}}" class='current-page'>Home</a> </li>
            <li> <a href="{{route('categories.index')}}">Category</a> </li> 
            <li> <a href='#' data-bs-toggle="modal" data-bs-target="#blogModal"> Create Blog</a> </li>
          </ul>
        </nav>
      </div>
    </header> 
    
    <div class="container container-flex">
      
      @yield('content')

      
          <br />
        
        </div>  
   </div>


   <footer>
      <p><strong>Living the Simple Life</strong></p>
      <p>Copyright 2023, <a href='' target='_blank'>Simple Blog</a></p>
      
    </footer>
   

</body >

<script>
  let id = "";
  //selectcatData();
 
 //localStorage.clear();
  selectData();
  
  var parentDiv = document.getElementById('result');
    
  

  /*category crud*/



  function add(){
    var reader = new FileReader();
var name = document.getElementById('image').files[0].name;
reader.addEventListener('load',function(){
//   //alert(this.result)
//   if(this.result){
// var show=this.result;
localStorage.setItem('img',this.result);
 });
    reader.readAsDataURL(document.getElementById('image').files[0]);

    let res = window.localStorage.getItem('img');
      
      document.getElementById('msg').innerHTML="";
      var blogname =document.getElementById("name").value;
      var slug =document.getElementById("slug").value;
      var description =document.getElementById("description").value;
      var category =document.getElementById("category").value;
     
      if(blogname==''){
        document.getElementById('nameErrorMsg').innerHTML="please enter your name";
      }
      else if (slug=='') {
        document.getElementById('slugErrorMsg').innerHTML="please enter slug";
      }
      // else if (name=='') {
      //   document.getElementById('imageErrorMsg').innerHTML="please upload image";
      // }
      else if (description=='') {
        document.getElementById('descriptionErrorMsg').innerHTML="please enter description";
      }
      
      else{
        
        if(id==''){
          let arr=getCrudData();
          
          if(arr==null){
            
          let data={name:blogname,slug:slug,image:res,description:description,category:category};
          localStorage.setItem('crud',JSON.stringify(data));
          alert(data)
          console.log(data)
        
                      }
          else{
          var newObj ={name: blogname,slug :slug,image:res,description:description,category:category};
          arr.push(newObj);
           setCrudData(arr)
         
              }

       
              document.getElementById('msg').classList.add('show');
              document.getElementById('msg').classList.remove('show');
        document.getElementById('msg').innerHTML=" data added";
        setTimeout(function(){
          
          //document.getElementsByClassName('modal-backdrop').classList.add('hide');
          document.getElementsById('blogModal').classList.add('hide');
        }, 3000);
        //document.getElementById('blogModal').style.display="none";
             }else{
              document.getElementById('msg-danger').classList.add('show');
              document.getElementById('msg-danger').innerHTML="cannot insert data added";
              setTimeout(function(){
          document.getElementById('msg-danger').classList.remove('show');
     }, 3000);      
            }
                }
                
        selectData();
        
      
      //var name =document.querySelector(".name").value;
      // var description =document.querySelector("#description").value;
      // var newObj = {id: 3,name: name,description :description}
      
      // data.push(newObj);
      // readAll();
    }


//     function showImages(){
      
//    //let res = window.localStorage.getItem(this.result)
//  var parentDiv = document.getElementById('result')
// // var show =document.getElementById('myImg');

//   //for(let i=0;i<window.localStorage.length;i++){
    
//      let res = window.localStorage.getItem('img');
// //     
//      var im=res;

     

//       //let html='';
      
//         //html=html+`<div><h3 style="color:#7c92b8; font-size:20px; " class="article-title"> Blogs</h2><img src="${im}">`

//    //parentDiv.innerHTML=html;

// // // //     // objectdata.map(record=>(
// // // //     //   parentDiv.appendChild(`<tr><td>${record.res}</td></tr>`)
// // // //     //   ));
//  //}
//  }
//showImages()

function selectData(){

  
  
  
  var parentDiv = document.getElementById('result');
 
 // var imageParent = document.getElementById("showim");
 // var image = document.createElement("img");
  let arr=JSON.parse(localStorage.getItem('crud'));
  
    if(arr!=null){
    let html='';
    
   // let sno=1;
     for(let k in arr)
     {
      
      var im=arr[k].image;
      
 

//       var image = new Image()
// //     //alert(image)
//      image.src = res;
//     parentDiv.appendChild(image)
      
      // image.src=arr[k].image;
      
      
      // imageParent.add(image);
      
        
      html=html+`<div><h3 style="color:#7c92b8; font-size:20px; " class="article-title">${ arr[k].category} Blogs</h2></div><article class="article-recent col-lg-12"><div class="article-recent-main col-lg-12"><h2 class="article-title">${ arr[k].name} </h2><p class="article-body" id="moreM">${ arr[k].description}</p><img src="${im}" id="myImg"  class="article-image"><button data-bs-toggle="modal" data-bs-target="#editBlogModal" onclick="editData(${k})" class="btn btn-primary edit" ><i class="fa fa-edit" style="font-size:24px"></i></button> <button class="btn btn-danger" onclick="deleteData(${k})"><i class="fa fa-trash-o" style="font-size:24px"></i></button><button class="btn btn-info" style="float:right;" data-bs-toggle="modal" data-bs-target="#blogModal"> Create Blog <i class="fa fa-plus"></i></button></div></article>`
      
      
      }
    
    parentDiv.innerHTML = html;
    
  }
  selectcatData()
}
    function editData(rid){
      
      var editformImg = document.getElementById('show');
      id=rid;
       let arr=getCrudData();
       let editshow='';
       //var img=URL.createObjectURL(document.getElementById("Inputimage").files[0]);
       //var img=document.getElementById("Inputimage").files[0].name;
       document.getElementById('Inputname').value=arr[rid].name;
       
       document.getElementById('Inputslug').value=arr[rid].slug;
       //img=arr[rid].image;
       document.getElementById('Inputdescription').value=arr[rid].description;
       var im=arr[rid].image;
       editshow=editshow+`<div><img src="${im}" style="width:200px;height:100px;margin-bottom:4px;" id="myImg"</div>`;
       //document.getElementById('Inputcategory').value=arr[rid].category;
       editformImg.innerHTML = editshow;
      }
 function updateData(){
  
 
  var reader = new FileReader();
var name = document.getElementById('Inputimage').files[0].name;

reader.addEventListener('load',function(){
  //alert(this.result)
  if(this.result){
var show=this.result;
localStorage.setItem('img',this.result);
  }
 });
 if(name!=''){
   reader.readAsDataURL(document.getElementById('Inputimage').files[0]);
   
 
 }
 
 let res = localStorage.getItem('img');
   
    
  var nameb =document.getElementById("Inputname").value;
  //var name=document.getElementById("Inputimage").files[0].name;
      
  //name.value='';
      var slug =document.querySelector("#Inputslug").value;
      var description =document.querySelector("#Inputdescription").value; 
      var category =document.querySelector("#Inputcategory").value; 


 
        let arr=getCrudData();
        if(arr!==null){
          arr[id].name=nameb;
          arr[id].slug=slug;
          arr[id].description=description;
          arr[id].category=category;
          arr[id].image=res;
          
          
         setCrudData(arr);
         alert("saved");
         location.reload();
         //document.getElementById('msg').classList.add('show');
        document.getElementById('msg').innerHTML="data added";
        setTimeout(function(){
          //document.getElementById('msg').classList.remove('show');
          //document.getElementsByClassName('modal-backdrop').classList.add('hide');
          document.getElementById('editBlogModal').classList.add('hide');
        }, 2000);
      }
      else{
        alert("error updating data")
        document.getElementById('msg').innerHTML="error updating data";
      }
      
   selectData();
}



function getCrudData(){
  let arr=JSON.parse(localStorage.getItem('crud'));
  
  return arr;
}
function setCrudData(arr){
  localStorage.setItem('crud',JSON.stringify(arr));
  
}

function deleteData(rid){
  let arr=getCrudData();
  arr.splice(rid,1);
  document.getElementById('msg').style.display="block";
  setCrudData(arr);
  selectData();
}












function addcat(){
 
 var name =document.getElementById("catname").value;
    
      var slug =document.getElementById("catslug").value;
      if(name==''){
        document.getElementById('nameErrorMsg').innerHTML="please enter your name";
      }
      else if (slug=='') {
        document.getElementById('slugErrorMsg').innerHTML="please enter slug";
      }
      else{
        if(id==''){
          let arr=getcatCrudData();
          if(arr==null){
            
          let data={name:name,slug:slug};
          console.log(data);
          localStorage.setItem('crudcat',JSON.stringify(data));
          }
          else{
          var newObj = {name: name,slug :slug}
          
          arr.push(newObj);
          
           setCatData(arr)
           
              }

       
       
              document.getElementById('msg').classList.add('show');
        document.getElementById('msg').innerHTML=" data added";
        setTimeout(function(){
          document.getElementById('msg').classList.remove('show');
          //document.getElementsByClassName('modal-backdrop').classList.add('hide');
          document.getElementById('editCategoryModal').classList.add('hide');
        }, 2000);
        //document.getElementById('blogModal').style.display="none";
             }else{
              document.getElementById('msg-danger').classList.add('show');
              document.getElementById('msg-danger').innerHTML="cannot insert data added";
              setTimeout(function(){
          document.getElementById('msg-danger').classList.remove('show');
     }, 2000);    
                  }

                }
        selectcatData();
      
      //var name =document.querySelector(".name").value;
      // var description =document.querySelector("#description").value;
      // var newObj = {id: 3,name: name,description :description}
      
      // data.push(newObj);
      // readAll();
    }


    function selectcatData(){

      var parentDiv = document.getElementById('table');
  var catdiv=document.getElementById('category');
  var cateditdiv=document.getElementById('inputcategory');
  let arr=JSON.parse(localStorage.getItem('crudcat'));
 
  
  //var arr=JSON.parse(localStorage.getItem('crudcat'));
  
  if(arr!=null){
    
    //let html='';
    // let cat='';
    // let catedit='';
   // let sno=1;
     for(let k in arr)
     {
      
      
      var optionadd = document.createElement("option");
      var optionedit = document.createElement("option");
      
      optionadd.innerHTML = arr[k].name;
      optionedit.innerHTML = arr[k].name;
      catdiv.add(optionadd);
      cateditdiv.add(optionedit);
      optionadd++;
      optionedit++;
      
       
      //html=html+`<tr><td>${ arr[k].name}</td><td>${ arr[k].slug}</td><td><button class="btn btn-primary edit" type="button"  data-bs-toggle="modal" data-bs-target="#editCategoryModal"  onclick="editcatData(${k})" >Edit</button> <button onclick="deletecatData(${k})" class="btn btn-danger">Delete</button> </td> </tr>  `;
      
      //))
      //sno++;
      }
    
    //parentDiv.innerHTML = html;
    //catdiv.innerHTML = cat;
    //cateditdiv.innerHTML =catedit;
  }

    }

    function getcatCrudData(){
  let arr=JSON.parse(localStorage.getItem('crudcat'));
  return arr;
}


function setCatData(arr){
  localStorage.setItem('crudcat',JSON.stringify(arr));
  
}

function editcatData(rid){
      
      
      id=rid;
       let arr=getcatCrudData();
       console.log(arr);
       //var img=URL.createObjectURL(document.getElementById("Inputimage").files[0]);
       //var img=document.getElementById("Inputimage").files[0].name;
       document.getElementById('Inputcatname').value=arr[rid].name;
       
       document.getElementById('Inputcatslug').value=arr[rid].slug;
       //img=arr[rid].image;

      
       
    }
 function updatecatData(){
  var name =document.getElementById("Inputcatname").value;
  
      
  //name.value='';
      var slug =document.querySelector("#Inputcatslug").value;
      
  let arr=getcatCrudData();
  
  //console.log(arr[id]);
          arr[id].name=name;
          arr[id].slug=slug;
          
          
         setCatData(arr);
         document.getElementById('msg').classList.add('show');
        document.getElementById('msg').innerHTML=" data added";
        setTimeout(function(){
          document.getElementById('msg').classList.remove('show');
          //document.getElementsByClassName('modal-backdrop').classList.add('hide');
          document.getElementsByClassName('modal').classList.add('hide');
        }, 2000);
   selectcatData();
}



function deletecatData(rid){
  let arr=getcatCrudData();
  arr.splice(rid,1);
  document.getElementById('msg').style.display="block";
  setCatData(arr);
  selectcatData();
}


// $(".httpbin").click(function(){
//   setTimeout(function(){
    
//     $(".modal-backdrop").hide();
//     $(".modal").hide(); 
//   }, 2000);
// })
  
</script>






</html>
