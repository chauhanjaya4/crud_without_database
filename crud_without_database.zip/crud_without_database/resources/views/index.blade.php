
    


<!--create blog modal ends-->

<!--edit modal-->


<!--edit modal ends-->

   
    
    <!-- container starts -->
    
        @extends('layouts.app')

<!-- Specify content -->
<!--display data-->
@section('content')


<main role="main" id="result">
   

   
   
   
                  
                
                
                
            </main>
           
           
    @endsection
    