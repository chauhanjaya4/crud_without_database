
<div class="modal fade" id="editCategoryModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content category">
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Edit Blog</h2>
                </div>
                <div class="pull-right">
                    <a class="btn btn-primary" href="{{ route('categories.index') }}" enctype="multipart/form-data">
                        Back</a>
                </div>
            </div>
        </div>
        
        <form   id="categoryeditForm" >
            
            
            
            
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                
                    <div class="form-group">
                        <strong>Category Name:</strong>
                        <input type="text" name="name" id="Inputcatname"  class="form-control"
                            placeholder="Enter Category name">
                            <span class="text-danger" id="nameErrorMsg"></span>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Slug:</strong>
                        <input type="text" name="slug" id="Inputcatslug" class="form-control" placeholder="Enter Slug"
                            >
                            <span class="text-danger" id="slugErrorMsg"></span>
                    </div>
                </div>
                
               
                <div class="container_btn">
  <div class="center_btn">
                <button onclick="updatecatData()" id="submit" style="width:100%;" class="btn btn-primary httpbin ">Submit</button>
</div>
</div>
            </div>
        </form>

        <div  class="alert alert-success" id="msg"></div>
            <div  class="alert alert-danger" id="msg-danger"></div>
    </div>
</div>
</div>
</div>
