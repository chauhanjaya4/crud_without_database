<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="container">
    <div class="col-sm-offset-0 col-sm-12 ">
        <div class="panel panel-default">
            <div id="header" class="panel-heading">
                <h4><i class="fa fa-btn fa-users"></i>Test</h4>
            </div>

            <div class="panel-body">

                <form action="<?php echo e(route('test.post')); ?>" method="POST">
                    <?php echo csrf_field(); ?> 
                    <?php if(isset($text)): ?>
                    <input type="text" name="text" value="<?php echo e($text); ?>">                                      
                    <?php else: ?>
                    <input type="text" name="text" >                                      
                    <?php endif; ?>
                    <input type="submit">
                </form>
            </div>
        </div>
    </div>
</div>

<form action="<?php echo e(route('test.post')); ?>" enctype="multipart/form-data" id="blogForm" method="POST">
                    <?php echo csrf_field(); ?> 
                    <!-- <?php if(isset($text)): ?> -->
                    <input type="text"  name="text" value="<?php echo e($text); ?>">                                      
                    <!-- <?php else: ?> -->
                    <input type="text" name="text" >                                      
                    <!-- <?php endif; ?> -->
                    <input type="submit">
                </form>

                <h2 class="article-title"><?php echo e($text); ?></h2>
</body>
</html><?php /**PATH C:\xampp\htdocs\dummy\resources\views/test/index.blade.php ENDPATH**/ ?>