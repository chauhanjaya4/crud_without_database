<?php echo $__env->make('blogs.modals.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
    <title>Blog</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" > -->
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script> -->
   
        <style>
            
/* Typography */
@import  url('https://fonts.googleapis.com/css2?family=Lora&display=swap');
@import  url('https://fonts.googleapis.com/css2?family=Lora&family=Ubuntu:wght@300;400;700&display=swap');
body {
    margin: 0;
    font-family: 'Ubuntu', sans-serif;
    font-size: 1.125rem;
    font-weight: 300;
}
h1, 
h2,
h3 {
    font-family: 'Lora', serif;
    font-weight: 400;
    color: #143774;
    margin-top: 0;
}
h1{
  font-size: 2rem;
  margin: 0;
}
a {
    color: #1792d2;
}

a:hover,
a:focus {
    color: #143774;
}

strong {
    font-weight: 700;
}
.subtitle{
  font-size: 0.85rem;
  font-weight: 700;
  margin: 0;
  color: #1792d2;
  letter-spacing: 0.05em;
  font-family: 'Ubuntu Bold', sans-serif;
}
.article-title {
    font-size: 1.5rem;
}

.article-read-more,
.article-info {
    font-size: .875rem;
}

.article-read-more {
    color: #1792d2;
    text-decoration: none;
    font-weight: 700;
}
.article-read-more:hover,
.article-read-more:focus {
    color: #143774;
    text-decoration: underline;
}
.article-info {
    margin: 2em 0;
}
header{
  padding: 1rem 0;
  text-align: center;
  background: #f0f8ff;
  font-family: sans-serif;
  margin-bottom: 3em;
}
.container-flex{
  max-width: 70vw;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  margin-bottom: 1em;
}
nav ul{
  display: flex;
  justify-content: center;
  list-style: none;
  padding: 0;
}
nav li{
  margin: 0 1em;
}
nav a{
  text-decoration: none;
  color: #707070;
  font-weight: 700; 
  padding: 0.25em 0;
}

nav a:hover,
nav a:focus{
  color: #143774;
  border-bottom: 1px solid black;
  transition: .3s ease;
}

img{
  max-width: 100%;
  display: block;
}
main{
  max-width: 75%;
}
.article-body{
  width: 100%;
  text-align: justify;
}
.sidebar{
  max-width: 23%;
}
footer {
    background:#143774;
    color: white;
    text-align: center;
    padding: 3em 0;
}
footer a{
  text-decoration: none;
  color: white;
}
footer a:hover{
  text-decoration: underline;
  color: white;
}
@media (max-width:1050px){
  .container-flex{
    flex-direction: column;
  }
  .site-title, .subtitle{
    width: 100%;
  }
  main{
    max-width: 100%;
  }
  .sidebar{
    max-width: 100%;
  }
  
}
@media (max-width: 500px){
  nav ul{
    display: flex;
    flex-direction: column;
  }
  nav li{
    margin: 0.5em 0;
  }
}

/* articles */
.article-featured {
    border-bottom: #707070 1px solid;
    padding-bottom: 2em;
    margin-bottom: 2em;
}
.article-recent {
    display: flex;
    flex-direction: column;
    margin-bottom: 2em;
}

.article-recent-main {
    order: 2;
}

.article-recent-secondary {
    order: 1;
}

.container_btn{
  position: relative;
}
.center_btn{
  margin: 0;
  width:100%;
}
@media (min-width: 675px) {
    .article-recent {
        flex-direction: row;
        justify-content: space-between;
    }
    
    .article-recent-main {
        width: 68%;
    }
    
    .article-recent-secondary {
        width: 30%;
    }
}
.container_btn{
  position: relative;
}
.center_btn{
  margin: 0;
  width:100%;
}
/* .article-body.more-text{
  display:none;
} */

        </style>
    </head>
    <body >
    <header>
      <div class='container container-flex'>
        <div class='site-title'>
          <h1>Living The Social Life</h1>
          <p class='subtitle'>A blog exploring minimalism in life.</p>
        </div>
        <nav>
          <ul>
            <li> <a href='#' class='current-page'>Home</a> </li>
            <li> <a href="<?php echo e(route('categories.index')); ?>">Category</a> </li>
            <li> <a href='#' data-bs-toggle="modal" data-bs-target="#blogModal"> Create Blog</a> </li>
          </ul>
        </nav>
      </div>
    </header> 
    
    <div class="container container-flex">
      
      <?php echo $__env->yieldContent('content'); ?>
   </div>


   <footer>
      <p><strong>Living the Simple Life</strong></p>
      <p>Copyright 2023, <a href='' target='_blank'>Simple Blog</a></p>
      
    </footer>
    <script>
     //debugger;
$(document).ready(function(){
/*create blog*/

 $(document).on('submit','#blogForm',function(e){
      e.preventDefault();
      
      let name = $('#InputName').val();
    let slug = $('#InputSlug').val();
    let category = $('#InputCategory').val();
    let image = $('#InputImage').val();
    let description = $('#InputDescription').val();
    //let message = $('#InputMessage').val();
       let formData = new FormData($('#blogForm')[0]);
       $.ajax({
       url: "/blogs",
       headers:{
         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
          type: "POST",
          data: formData,
          contentType:false,
          processData:false,
          success: function( response ) {
       console.log(response)
$('#submit').html('Submit');
 $("#submit"). attr("disabled", false);
 $('#successMsg').show();
 window.location.reload();
 //$('#blogModal').modal('hide');
// setTimeout(function(){$('#blogModal').modal('hide');},5000)
 
 document.getElementById("blogForm").reset(); 
 setTimeout(function(){
            $('#successMsg').hide();
            $('#msg_div').hide();
            
            },2000);
 },
 error: function(response) {
        $('#nameErrorMsg').text(response.responseJSON.errors.name);
        $('#slugErrorMsg').text(response.responseJSON.errors.slug);
        $('#categoryErrorMsg').text(response.responseJSON.errors.category);
        $('#imageErrorMsg').text(response.responseJSON.errors.image);
        $('#descriptionErrorMsg').text(response.responseJSON.errors.description);
        //$('#messageErrorMsg').text(response.responseJSON.errors.message);
      },
});

       
    });


   $(document).on('click','.edit',function(){
    var id= $(this).val();
    //console.log(id);
$('#editBlogModal').modal('show');

 $.ajax({
        url: "blogs-edit/"+id,
       type: "GET",
       success: function( response ) {
        // console.log(response.blog);
        // console.log(response.blog.name);
        
        $("#name").val(response.blog.name);
       $("#slug").val(response.blog.slug);
          //$("#image").val(response.blog.image);
         $("#description").val(response.blog.description);
        
       }
         });
});

  
/*blog update form*/

$(document).on('submit','#blogeditForm',function(e){
      e.preventDefault();
      //var id= $("#id").val();
      //var id= $(this).val();
      console.log(id);
      let name = $('#name').val();
    let slug = $('#slug').val();
    //let category = $('#InputCategory').val();
    let image = $('#image').val();
    let description = $('#description').val();
    //let message = $('#InputMessage').val();
       let formData = new FormData($('#blogeditForm')[0]);
       $.ajax({
       url: "blogs-update/"+id,
       headers:{
         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
          type: "POST",
          data: formData,
          contentType:false,
          processData:false,
          success: function( response ) {
       
$('#submit').html('Submit');
 $("#submit"). attr("disabled", false);
 $('#successMsg').show();
 $('#blogeditModal').modal('hide');
// setTimeout(function(){$('#blogModal').modal('hide');},5000)
 
 document.getElementById("blogeditForm").reset(); 
 setTimeout(function(){
            $('#successMsg').hide();
            $('#msg_div').hide();
            
            },2000);
 },
 error: function(response) {
        $('#nameErrorMsg').text(response.responseJSON.errors.name);
        $('#slugErrorMsg').text(response.responseJSON.errors.slug);
        //$('#categoryErrorMsg').text(response.responseJSON.errors.category);
        $('#imageErrorMsg').text(response.responseJSON.errors.image);
        $('#descriptionErrorMsg').text(response.responseJSON.errors.description);
        //$('#messageErrorMsg').text(response.responseJSON.errors.message);
      },
});

       
   });

   /* continue reading*/

//    $(document).ready(function(){
// 	var maxLength = 10;
// 	$(".article-body").each(function(){
// 		var myStr = $(this).text();
// 		if($.trim(myStr).length > maxLength){
// 			var newStr = myStr.substring(0, maxLength);
// 			var removedStr = myStr.substring(maxLength, $.trim(myStr).length);
// 			$(this).empty().html(newStr);
// 			$(this).append(' <a href="javascript:void(0);" class="article-read-more read-more">CONTINUE READING...</a>');
// 			$(this).append('<span class="more-text">' + removedStr + '</span>');
// 		}
// 	});
// 	$(".read-more").click(function(){
// 		$(this).siblings(".more-text").contents().unwrap();
// 		$(this).remove();
// 	});
// });


});
</script>
<script>
function readMoreM() {
    var dotsM = document.getElementById("dotsM");
    var moreTextM = document.getElementById("moreM");
    var btnTextM = document.getElementById("myBtnM");

    if (dotsM.style.display === "none") {
        dotsM.style.display = "inline";
        btnTextM.innerHTML = "CONTINUE READING";
        moreTextM.style.display = "none";
    } else {
        dotsM.style.display = "none";
        btnTextM.innerHTML = "Read less";
        moreTextM.style.display = "inline";
    }
    console.log()
}  
</script>
</body>










</html>
<?php /**PATH C:\xampp\htdocs\Blog_crud\resources\views/layouts/app.blade.php ENDPATH**/ ?>