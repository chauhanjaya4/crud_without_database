<?php echo $__env->make('blogs.modals.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('blogs.modals.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('categories.modals.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('categories.modals.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
    <title>Blog</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" > -->
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script> -->
   
        <style>
            
/* Typography */
@import  url('https://fonts.googleapis.com/css2?family=Lora&display=swap');
@import  url('https://fonts.googleapis.com/css2?family=Lora&family=Ubuntu:wght@300;400;700&display=swap');
body {
    margin: 0;
    font-family: 'Ubuntu', sans-serif;
    font-size: 1.125rem;
    font-weight: 300;
}
h1, 
h2,
h3 {
    font-family: 'Lora', serif;
    font-weight: 400;
    color: #143774;
    margin-top: 0;
}
h1{
  font-size: 2rem;
  margin: 0;
}
a {
    color: #1792d2;
}

a:hover,
a:focus {
    color: #143774;
}

strong {
    font-weight: 700;
}
.subtitle{
  font-size: 0.85rem;
  font-weight: 700;
  margin: 0;
  color: #1792d2;
  letter-spacing: 0.05em;
  font-family: 'Ubuntu Bold', sans-serif;
}
.article-title {
    font-size: 1.5rem;
}

.article-read-more,
.article-info {
    font-size: .875rem;
}

.article-read-more {
    color: #1792d2;
    text-decoration: none;
    font-weight: 700;
}
.article-read-more:hover,
.article-read-more:focus {
    color: #143774;
    text-decoration: underline;
}
.article-info {
    margin: 2em 0;
}
header{
  padding: 1rem 0;
  text-align: center;
  background: #f0f8ff;
  font-family: sans-serif;
  margin-bottom: 3em;
}
.container-flex{
  max-width: 70vw;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  margin-bottom: 1em;
}
nav ul{
  display: flex;
  justify-content: center;
  list-style: none;
  padding: 0;
}
nav li{
  margin: 0 1em;
}
nav a{
  text-decoration: none;
  color: #707070;
  font-weight: 700; 
  padding: 0.25em 0;
}

nav a:hover,
nav a:focus{
  color: #143774;
  border-bottom: 1px solid black;
  transition: .3s ease;
}

img{
  max-width: 100%;
  display: block;
}
main{
  max-width: 75%;
}
.article-body{
  width: 100%;
  text-align: justify;
}
.sidebar{
  max-width: 23%;
}
footer {
    background:#143774;
    color: white;
    text-align: center;
    padding: 3em 0;
}
footer a{
  text-decoration: none;
  color: white;
}
footer a:hover{
  text-decoration: underline;
  color: white;
}
@media (max-width:1050px){
  .container-flex{
    flex-direction: column;
  }
  .site-title, .subtitle{
    width: 100%;
  }
  main{
    max-width: 100%;
  }
  .sidebar{
    max-width: 100%;
  }
  
}
@media (max-width: 500px){
  nav ul{
    display: flex;
    flex-direction: column;
  }
  nav li{
    margin: 0.5em 0;
  }
}

/* articles */
.article-featured {
    border-bottom: #707070 1px solid;
    padding-bottom: 2em;
    margin-bottom: 2em;
}
.article-recent {
    display: flex;
    flex-direction: column;
    margin-bottom: 2em;
}

.article-recent-main {
    order: 2;
}

.article-recent-secondary {
    order: 1;
}

.container_btn{
  position: relative;
}
.center_btn{
  margin: 0;
  width:100%;
}
@media (min-width: 675px) {
    .article-recent {
        flex-direction: row;
        justify-content: space-between;
    }
    
    .article-recent-main {
        width: 68%;
    }
    
    .article-recent-secondary {
        width: 30%;
    }
}
.container_btn{
  position: relative;
}
.center_btn{
  margin: 0;
  width:100%;
}

.article-image{
  width:100%;
  height:300px;
  margin-top:10px;
  margin-bottom:10px;
}

.category{height:300px;}
          .container_btn{
  position: relative;
}
.center_btn{
  margin: 0;
  width:100%;
}

#msg{
  display:none;
}
#msg{
  display:none;
}


#msg-danger{
  display:none;
}

.show{
  display:block;
}

.hide{
  display:none;
};
/* .article-body.more-text{
  display:none;
} */

        </style>
    </head>
    <body>
    <header>
      <div class='container container-flex'>
        <div class='site-title'>
          <h1>Living The Social Life</h1>
          <p class='subtitle'>A blog exploring minimalism in life.</p>
        </div>
        <nav>
          <ul>
            <li> <a href="<?php echo e(url('/')); ?>" class='current-page'>Home</a> </li>
            <li> <a href="<?php echo e(route('categories.index')); ?>">Category</a> </li> 
            <li>  </li>
          </ul>
        </nav>
      </div>
    </header> 
    
    <div class="container container-flex">
      
      <?php echo $__env->yieldContent('content'); ?>

      
          <br />
        
        </div>  
   </div>


   <footer>
      <p><strong>Living the Simple Life</strong></p>
      <p>Copyright 2023, <a href='' target='_blank'>Simple Blog</a></p>
      
    </footer>
   

</body >






<script>
  /*category crud*/
  //localhost.clear();
  let id = "";
  selectcatData();
function addcat(){
 
 var name =document.getElementById("catname").value;
    
      var slug =document.getElementById("catslug").value;
      if(name==''){
        document.getElementById('nameErrorMsg').innerHTML="please enter your name";
      }
      else if (slug=='') {
        document.getElementById('slugErrorMsg').innerHTML="please enter slug";
      }
      else{
        if(id==''){
          let arr=getcatCrudData();
          if(arr==null){
            
          let data={name:name,slug:slug};
          console.log(data);
          localStorage.setItem('crudcat',JSON.stringify(data));
          }
          else{
          var newObj = {name: name,slug :slug};
          
          arr.push(newObj);
          
           setCatData(arr)
           
              }

       
       
              document.getElementById('msg').classList.add('show');
        document.getElementById('msg').innerHTML=" data added";
        setTimeout(function(){
          document.getElementById('msg').classList.remove('show');
          //document.getElementsByClassName('modal-backdrop').classList.add('hide');
          document.getElementById('createCategoryModal').classList.add('hide');
        }, 2000);
        //document.getElementById('blogModal').style.display="none";
             }else{
              document.getElementById('msg-danger').classList.add('show');
              document.getElementById('msg-danger').innerHTML="cannot insert data added";
              setTimeout(function(){
          document.getElementById('msg-danger').classList.remove('show');
     }, 2000);    
                  }

                }
        selectcatData();
      
      //var name =document.querySelector(".name").value;
      // var description =document.querySelector("#description").value;
      // var newObj = {id: 3,name: name,description :description}
      
      // data.push(newObj);
      // readAll();
    }


    function selectcatData(){

      var parentDiv = document.getElementById('table');
  //    var catdiv=document.getElementById('category');
      
  // var cateditdiv=document.getElementById('inputcategory');
  let arr=JSON.parse(localStorage.getItem('crudcat'));
 
  
  //var arr=JSON.parse(localStorage.getItem('crudcat'));
  
  if(arr!=null){
    
    let html='';
    // let cat='';
    // let catedit='';
   // let sno=1;
     for(let k in arr)
     {
      
      
      // var option = document.createElement("option");
      // var optionedit = document.createElement("option");
      
      // option.innerHTML = arr[k].name;
      // optionedit.innerHTML = arr[k].name;
      // catdiv.add(option);
      // cateditdiv.add(optionedit);
      // option++;
      
      // optionedit++;
      
       
      html=html+`<tr><td>${ arr[k].name}</td><td>${ arr[k].slug}</td><td><button class="btn btn-primary edit" type="button"  data-bs-toggle="modal" data-bs-target="#editCategoryModal"  onclick="editcatData(${k})" >Edit</button> <button onclick="deletecatData(${k})" class="btn btn-danger">Delete</button> </td> </tr>  `
      //))
      //sno++;
      }
    
    parentDiv.innerHTML = html;
    // catdiv.innerHTML = cat;
    console.log(cat)
    // cateditdiv.innerHTML = catedit;
  }

    }

    function getcatCrudData(){
  let arr=JSON.parse(localStorage.getItem('crudcat'));
  return arr;
}


function setCatData(arr){
  localStorage.setItem('crudcat',JSON.stringify(arr));
  
}

function editcatData(rid){
      
      
      id=rid;
       let arr=getcatCrudData();
       console.log(arr);
       //var img=URL.createObjectURL(document.getElementById("Inputimage").files[0]);
       //var img=document.getElementById("Inputimage").files[0].name;
       document.getElementById('Inputcatname').value=arr[rid].name;
       
       document.getElementById('Inputcatslug').value=arr[rid].slug;
       //img=arr[rid].image;

      
       
    }
 function updatecatData(){
  var name =document.getElementById("Inputcatname").value;
  
      
  //name.value='';
      var slug =document.querySelector("#Inputcatslug").value;
      
  let arr=getcatCrudData();
  
  //console.log(arr[id]);
          arr[id].name=name;
          arr[id].slug=slug;
          
          
         setCatData(arr);
         document.getElementById('msg').classList.add('show');
        document.getElementById('msg').innerHTML=" data added";
        setTimeout(function(){
          document.getElementById('msg').classList.remove('show');
          //document.getElementsByClassName('modal-backdrop').classList.add('hide');
          document.getElementById('editCategoryModal').classList.add('hide');
        }, 2000);
   selectcatData();
}



function deletecatData(rid){
  let arr=getcatCrudData();
  arr.splice(rid,1);
  document.getElementById('msg').style.display="block";
  setCatData(arr);
  selectcatData();
}
  </script>
</html><?php /**PATH C:\xampp\htdocs\dummy\resources\views/layouts/appcat.blade.php ENDPATH**/ ?>