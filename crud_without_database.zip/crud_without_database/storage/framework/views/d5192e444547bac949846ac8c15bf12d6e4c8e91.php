<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name')); ?></title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">

        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    </head>

    <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand" href="<?php echo e(route('blogs.index')); ?>"><?php echo e(config('app.name')); ?></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="<?php echo e(route('blogs.index')); ?>">Home <span class="sr-only">(current)</span></a>
                    </li>
                </ul>

                <a href="<?php echo e(route('blogs.create')); ?>" class="btn btn-success my-2 my-sm-0">Create Post</a>
            </div>
        </nav>

        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <h4 class="alert-heading">Success!</h4>
                <p><?php echo e(Session::get('success')); ?></p>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if(Session::has('errors')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <h4 class="alert-heading">Error!</h4>
                <p>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </p>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        
        <div class="container py-3">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card">
                        <div class="card-header">
                            <h1><?php echo e($blog->name); ?></h1>
                        </div>

                        <div class="card-body">
                            <?php if($blog->image): ?>
                                <img src="<?php echo e(asset('storage/images/' . $blog->image)); ?>" alt="<?php echo e($blog->title); ?> photo" class="img-fluid">
                            <?php endif; ?>

                            <p><?php echo e($blog->description); ?></p>

                            <a href="<?php echo e(route('blogs.edit', $blog->slug)); ?>" class="btn btn-primary">Edit Post</a>
                            <form action="<?php echo e(route('blogs.destroy', $blog->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger mt-3">Delete</button>
                            </form>
                        </div><!--card-body end-->
                    </div><!--card end-->
                </div><!--col-md end-->
            </div><!--roe end-->
        </div><!--container end-->
        
    </body>

</html>
<?php /**PATH C:\xampp\htdocs\Blog_crud\resources\views/blogs/show.blade.php ENDPATH**/ ?>