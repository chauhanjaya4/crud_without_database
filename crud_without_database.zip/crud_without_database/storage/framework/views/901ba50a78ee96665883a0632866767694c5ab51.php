

<div class="modal fade" id="editBlogModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content category">

    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Edit Blog</h2>
                </div>
                <div class="pull-right">
                    <a class="btn btn-primary" href="<?php echo e(route('blogs.index')); ?>" enctype="multipart/form-data">
                        Back</a>
                </div>
            </div>
        </div>
        <div class="alert alert-success" role="alert" id="successMsg" style="display: none" >
  Blog updated successfully 
</div>
        <form action="<?php echo e(route('blogs.update',$blogs->id)); ?>" id="blogeditForm" method="POST"  enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="id"  name="id"/>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                 
                    <div class="form-group">
                        <strong>Blog Name:</strong>
                        <input type="text" name="name" id="name" value="" class="form-control"
                            placeholder="Enter Blog name">
                            <span class="text-danger" id="nameErrorMsg"></span>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Slug:</strong>
                        <input type="text" name="slug" id="slug" class="form-control" placeholder="Enter Slug"
                            value="">
                            <span class="text-danger" id="slugErrorMsg"></span>
                    </div>
                </div>
                <!-- <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                    <strong>Category:</strong>
                    <select name="category_id" class="block w-full mt-1 rounded-md" placeholder="Select Category">
                    <option 
                                        value="">Select Category</option>
                                    <option 
                                        value=""><?php echo e($blog->category->name); ?></option>
                                    
                                </select>
                                
                       
                        
                        <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div> -->
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Image:</strong>
                        <input type="file" name="image" id="image" value="" class="form-control"
                            placeholder="Upload Image">
                            <span class="text-danger" id="imageErrorMsg"></span>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Description:</strong>
                        <input type="text" name="description" id="des" value="" class="form-control"
                            placeholder="Enter Description">
                            <span class="text-danger" id="descriptionErrorMsg"></span>
                    </div>
                </div>
                <div class="container_btn">
                 <div class="center_btn">
                   <button type="submit" id="submit" style="width:100%;" class="btn btn-primary ">Submit</button>
</div>
</div>
            
                </div>
        </form>
    </div>
</div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\Blog_crud\resources\views/blogs/modals/edit.blade.php ENDPATH**/ ?>