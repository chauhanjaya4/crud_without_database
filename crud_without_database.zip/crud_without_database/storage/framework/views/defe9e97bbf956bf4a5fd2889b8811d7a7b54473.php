
    
    <!--create blog modal-->
    <div class="modal fade" id="blogModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left mb-2">
                    <h2>Add Blog</h2>
                </div>
                <div class="pull-right">
                    <a class="btn btn-primary" href="<?php echo e(route('blogs.index')); ?>"> Back</a>
                </div>
            </div>
        </div>
        

        <div class="alert alert-success" role="alert" id="successMsg" style="display: none" >
  Blog created successfully 
</div>
        <form method="POST"  enctype="multipart/form-data" id="blogForm" action="<?php echo e(route('blogs.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong> Name:</strong>
                        <input type="text"  id="InputName" name="name" class="form-control"  placeholder="Blog Name">
                        <span class="text-danger" id="nameErrorMsg"></span>
                       
                        
                       
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Slug:</strong>
                        <input type="text"  id="InputSlug" name="slug" class="form-control" placeholder="Enter Slug">
                        <span class="text-danger" id="slugErrorMsg"></span>
                        
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Category:</strong>
                        <select name="category_id" class="form-control" id="InputCategory">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e($category->id === old('category_id') ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                </select>
                               
                                <span class="text-danger" id="categoryErrorMsg"></span>
                        
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Image:</strong>
                        <input type="file"  id="InputImage"  name="image" class="form-control" placeholder="upload image">
                        <span class="text-danger" id="imageErrorMsg"></span>
                        
                        
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Description:</strong>
                        <input type="text"  id="InputDescription" name="description" class="form-control" placeholder="Enter Description">
                        <span class="text-danger" id="descriptionErrorMsg"></span>
                        
                    </div>
                </div>
            </div>
            <div class="alert alert-success d-none" id="msg_div">
              <span id="res_message"></span>
      </div>
            <div class="container_btn">
  <div class="center_btn">
            <button type="submit"  id="submit" style="width:100%;" class="btn btn-primary ">Submit</button>
</div>
</div>
</div>
        </form>
    </div>
</div>
</div>
</div>

<!--create blog modal ends-->

<!--edit modal-->


<!--edit modal ends-->

   
    
    <!-- container starts -->
    
        

<!-- Specify content -->
<!--display data-->
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<main role="main">
   

    <div><h2 style="color:#7c92b8; font-size:25px; " class="article-title"><?php echo e($blog->category->name); ?> Blogs</h2></div>
   <hr/>
    <article class="article-recent col-lg-12">
  
                    <div class="article-recent-main col-lg-12">
                    
                        <h2 class="article-title"><?php echo e($blog->name); ?> </h2>
                        <!-- <?php if( strlen(strip_tags($blog->description)) > 50): ?> 
                                        <?php echo e(substr($blog->description,0,10)); ?> -->
                         <!-- <span id="dotsM">...</span> -->
                          <p class="article-body" id="moreM"><?php echo e(substr($blog->description,10)); ?></p>
                        <!-- <a href="#" onclick=" readMoreM()" id="myBtnM" class="article-read-more">CONTINUE READING</a> -->
                        <!-- <?php endif; ?>
                        <?php if($blog->image): ?> -->
                        <img src="<?php echo e(asset('storage/images/'.$blog->image)); ?>" alt="two dumplings on a wood plate with chopsticks" class="article-image">
                        <?php else: ?> 
                                    <span>No image found!</span>
                                    <?php endif; ?>
                        <p class="article-info"><?php echo e(date_format($blog->created_at," M d,Y ")); ?></p>
                        <form action="<?php echo e(route('blogs.destroy',$blog->id)); ?>" method="Post">
                          
                           <a href="<?php echo e(route('blogs.edit',$blog->id)); ?>"class="btn btn-primary edit" ><i class="fa fa-edit" style="font-size:24px"></i></a> 
                           <!-- <button class="btn btn-primary edit" type="button" data-bs-toggle="modal"  value="<?php echo e($blog->id); ?>" ><i class="fa fa-edit" style="font-size:24px"></i></button>  -->
                               <?php echo csrf_field(); ?>
                               <?php echo method_field('DELETE'); ?>
                               <button type="submit" class="btn btn-danger"><i class="fa fa-trash-o" style="font-size:24px"></i></button>
                           </form>
                        </div>
                    <div class="article-recent-secondary">
                    
                                    
                                  
                    </div>
                </article>
                
                
                
                
            </main>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Blog_crud\resources\views/blogs/index.blade.php ENDPATH**/ ?>