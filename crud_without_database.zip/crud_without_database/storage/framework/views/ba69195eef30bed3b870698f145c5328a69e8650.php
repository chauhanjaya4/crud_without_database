
<div class="modal fade" id="createCategoryModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content category" style="height:400px;">
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left mb-2">
                    <h2>Add Category</h2>
                </div>
                <div class="pull-right">
                    <a class="btn btn-primary" href="<?php echo e(route('categories.index')); ?>"> Back</a>
                </div>
            </div>
        </div>
        

        
        <form   >
        
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group input_area">
                        <strong> Name:</strong>
                        <input type="text" required  id="catname" name="name" class="form-control"  placeholder="Category Name">
                        <span class="text-danger" id="nameErrorMsg"></span>
                       
                        
                       
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group input_area">
                        <strong>Slug:</strong>
                        <input type="text" required id="catslug" name="slug" class="form-control" placeholder="Enter Slug">
                        <span class="text-danger" id="slugErrorMsg"></span>
                        
                    </div>
                </div>
                

                
                
            </div>
           
            <div class="container_btn">
  <div class="center_btn">
            <button onclick="addcat()"  id="submit" style="width:100%;" class="btn btn-primary httpbin ">Submit</button>
</div>
</div>
</div>
        </form>

        <div  class="alert alert-success d-none" id="msg"></div>
            <div  class="alert alert-danger d-none" id="msg-danger"></div>
    </div>
</div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\dummy\resources\views/categories/modals/create.blade.php ENDPATH**/ ?>