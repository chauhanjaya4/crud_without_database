
    


<!--create blog modal ends-->

<!--edit modal-->


<!--edit modal ends-->

   
    
    <!-- container starts -->
    
        

<!-- Specify content -->
<!--display data-->
<?php $__env->startSection('content'); ?>


<main role="main" id="result">
   

   
   
   
                  
                
                
                
            </main>
           
           
    <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dummy\resources\views/index.blade.php ENDPATH**/ ?>