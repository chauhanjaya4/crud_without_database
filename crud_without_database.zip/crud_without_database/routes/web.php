<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\TestController;
use App\Http\Controllers\catController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return view('index');
});

//Route::resource('/blogs', 'BlogController');
//Route::resource('/categories', 'CategoryController');
Route::get('/blogs', [BlogController::class,'store'])->name('blogs.index');
Route::post('/blogs', [BlogController::class,'store'])->name('blogs.store');
Route::get('/test', [TestController::class,'form'])->name('test.index');



Route::get('/blogs/create', [BlogController::class,'create'])->name('blogs.create');
 
 //Route::get('/blogs/show', [BlogController::class,'show'])->name('blogs.show');
 Route::get('blogs-edit/', [BlogController::class,'edit'])->name('blogs.edit');
 Route::post('blogs-update/{id}', [BlogController::class,'update'])->name('blogs.update');
 Route::delete('blogs/{blog}', [BlogController::class,'destroy'])->name('blogs.destroy');
 
 /* route cat*/

//  Route::get('cats', [catController::class,'index'])->name('categories.index');
// Route::post('cats', [catController::class,'store'])->name('cats.store');
// Route::get('cats-edit/{id}', [catController::class,'edit'])->name('cats.edit');
//  Route::put('cats-update/{id}', [catController::class,'update'])->name('cats.update');
//  Route::delete('cats/{blog}', [catController::class,'destroy'])->name('cats.destroy');

 /*category route*/
 Route::get('/category', [categoryController::class,'index'])->name('categories.index');
 Route::post('/category', [CategoryController::class,'store'])->name('categories.store');
 Route::get('category/{id}', [CategoryController::class,'edit']);
 /*category*/
 Route::post('cat/{id}', [CategoryController::class,'update'])->name('cat.update');
Route::delete('/categories/{category}', [CategoryController::class,'destroy'])->name('categories.destroy');
// Route::get('/', function () {
//     return view('welcome');
// });
